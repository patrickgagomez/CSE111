/*
 * Copyright (C) 2018-2022 David C. Harrison. All rights reserved.
 *
 * You may not use, distribute, publish, or modify this code without 
 * the express written permission of the copyright holder.
 */

// !!!! SEE LIST OF CITATIONS AT BOTTOM OF PROGRAM !!!!

//       anything cited at the bottom was either
//       directly or indirectly used/read to help
//       implement the code below successfully.

#include "radix.h"
#include <string>
#include <math.h>
#include <iostream>
#include <sstream>
#include <thread>

using namespace std;

void RadixSorter::sequentialMSD(
  std::vector<std::reference_wrapper<std::vector<unsigned int>>> &lists)
{
  //for every list in lists...
  for (std::vector<unsigned int>& list : lists){

    sortAlg(list);

    //optional to see results. (UNCOMMENT)
    //printList(list, list.size());
  }
}
    
void RadixSorter::embarrassinglyParallelMSD(
  std::vector<std::reference_wrapper<std::vector<unsigned int>>> &lists, 
  const unsigned int cores)
{
  unsigned int running = 0;
  unsigned int ran = 0;
  unsigned int i = 0;
  unsigned int numLists = lists.size();

  std::vector<std::thread> threads(cores);
  while (ran != numLists){
    while ((ran + running) != numLists && running != cores){
      threads.push_back(std::thread( [&, lists, i] { sortAlg(lists[i]); }));
      running++; i++;
    }

    for (std::thread & t : threads){
      if (t.joinable()){
        t.join();
        running--; ran++;
      }
    }
  }
}

void RadixSorter::trulyParallelMSD(
  std::vector<std::reference_wrapper<std::vector<unsigned int>>> &lists, 
  unsigned int cores) 
{ 
  for (std::vector<unsigned int>& list : lists){

    unsigned int c = cores;
    sortAlgThreaded(list, c);

    //optional to see results. (UNCOMMENT)
    //printList(list, list.size());
  }
}


// CUSTOM FUNCTIONS
/*
void RadixSorter::printList(std::vector<unsigned int> &list, int size){
  for (int i = 0; i < size; i++){
    std::cout << list[i] << ", ";
  }
  std::cout << std::endl;
}
*/

unsigned int RadixSorter::second_max_digit(unsigned int x, unsigned int off){
  unsigned int s = 0;
  unsigned int d = 10;
  if (x < 10){
    s = 0;
  } else if (x > 100000000){
    s = 9;
    if (x < 1000000000){
      s = 8;
    }
  } else {
    while (x > d){
      d *= 10;
       ++s;
    }
  }
  
  return (unsigned int)(x / pow(10, s - off)) % 10;
}

void RadixSorter::sortAlg (std::vector<unsigned int> &list){
  //create 10 individual lists for each possible number
    std::vector<std::vector<unsigned int>> indiv(10);
    for (unsigned int x : list){
      //and fill the lists with proper data
      indiv[second_max_digit(x, 0)].push_back(x);
    }

    //for each of the individual lists...
    for (int i = 0; i < 10; i++){
      //add a single list to a string list
      std::vector<string> strIndiv(indiv[i].size());
      for (unsigned int x : indiv[i]){
        //and push back string versions of the numbers
        auto s = std::to_string(x);
        strIndiv.push_back(s);
      }
    
      //sort the list of strings
      std::sort(strIndiv.begin(), strIndiv.end());

      //turn the list back into unsigned ints
      stringstream ss;
      int j = 0;
      for (string s : strIndiv){
        if (s.length() > 0){
          unsigned int x;
          ss << s;
          ss >> x;
          indiv[i][j] = x;
          j++;
          ss.clear();
        }
      }
    }

    //gather the size of the final list (all sub list sizes added together)
    int finSize = 0;
    for (int i = 0; i < 10; i++){
      finSize += indiv[i].size();
    }
    //create the final vector of UI
    std::vector<unsigned int> finalSort;
    //reserve enough space
    finalSort.reserve( finSize );

    //for each sublist of numbers, add them into the finalSort
    for (int i = 0; i < 10; i++){
      finalSort.insert(finalSort.end(), indiv[i].begin(), indiv[i].end());
    }

    //set the original list to the finalSort'd list
    int h = 0;
    for (unsigned int x : finalSort){
      list[h] = x;
      h++;
    }
}

void RadixSorter::sortAlgThreaded (std::vector<unsigned int> &list, unsigned int cores){
  //create 10 individual lists for each possible number
    std::vector<std::vector<unsigned int>> indiv(10);
    for (unsigned int x : list){
      //and fill the lists with proper data
      indiv[second_max_digit(x, 0)].push_back(x);
    }

    //for each of the individual lists...
    for (int i = 0; i < 10; i++){
      unsigned int running = 0;
      unsigned int ran = 0;
      unsigned int totalSubs = 10;

      //use threads here to speed up
      std::vector<std::thread> threads(cores);
      while (ran != totalSubs){
        while ((ran + running) != totalSubs && running != cores){
          threads.push_back(std::thread( [this, &indiv, i] { threadSort(indiv[i]); }));
          running++; i++;
        }

        for (std::thread & t : threads){
          if (t.joinable()){
            t.join();
            running--; ran++;
          }
        }
      }
    }

    //gather the size of the final list (all sub list sizes added together)
    int finSize = 0;
    for (int i = 0; i < 10; i++){
      finSize += indiv[i].size();
    }
    //create the final vector of UI
    std::vector<unsigned int> finalSort;
    //reserve enough space
    finalSort.reserve( finSize );

    //for each sublist of numbers, add them into the finalSort
    for (int i = 0; i < 10; i++){
      finalSort.insert(finalSort.end(), indiv[i].begin(), indiv[i].end());
    }

    //set the original list to the finalSort'd list
    int h = 0;
    for (unsigned int x : finalSort){
      list[h] = x;
      h++;
    }
}


void RadixSorter::threadSort(std::vector<unsigned int> &list){
  //add a single list to a string list
  if (list.size() <= 1){
    return;
  }

  std::vector<string> strIndiv(list.size());
  for (unsigned int x : list){
    //and push back string versions of the numbers
    auto s = std::to_string(x);
    strIndiv.push_back(s);
  }
    
  //sort the list of strings
  std::sort(strIndiv.begin(), strIndiv.end());

  //turn the list back into unsigned ints
  stringstream ss;
  int j = 0;
  for (string s : strIndiv){
    if (s.length() > 0){
      unsigned int x;
      ss << s;
      ss >> x;
      list[j] = x;
      j++;
      ss.clear();
    }
  }
}


//OLD CODE vvv
//i really tried with these sorting methods... brain hurting
/*
void RadixSorter::radixSort(std::vector<unsigned int> &list, int size, unsigned int off){
  countingSort(list, size, off);
}

void RadixSorter::countingSort(std::vector<unsigned int> &list, int size, unsigned int off){

  unsigned int output[size];
  int count[10] = { 0 };

  for (unsigned int i = 0; i < (unsigned int)size; i++){

    count[ second_max_digit(list[i], off) ]++;
  }

  for(unsigned int i = 1; i < 10; i++){
    count[i] += count[i-1];
  }
  
  for (unsigned int i = size - 1; i != -1 ; i--){
    output[ count[ second_max_digit(list[i], off) ] - 1 ] = list[i];
    count[ second_max_digit(list[i], off) ]--;
  }
  
  for (unsigned int i = 0; i < size; i++){
    list[i] = output[i];
  }
}
*/

/*
CITATION LIST:
jams: https://www.youtube.com/watch?v=qZjWUkohSQg
radix sorting: https://www.youtube.com/watch?v=jDL5lRPX6yI&t=637s
converting ints: https://stackoverflow.com/questions/5590381/easiest-way-to-convert-int-to-string-in-c
std::sort: https://en.cppreference.com/w/cpp/algorithm/sort
msd sorting: https://www.geeksforgeeks.org/msd-most-significant-digit-radix-sort/
multithreading vectors: https://stackoverflow.com/questions/54551371/creating-thread-inside-a-for-loop-c
using thread vectors: https://social.msdn.microsoft.com/Forums/SECURITY/en-US/b0d3e89b-c28b-470a-8523-e7d0f10f1437/creating-a-thread-inside-for-loop?forum=vcgeneral
creating thread vector: https://thispointer.com/c11-how-to-create-vector-of-thread-objects/
thread error message explaining: https://stackoverflow.com/questions/7381757/c-terminate-called-without-an-active-exception
*/

