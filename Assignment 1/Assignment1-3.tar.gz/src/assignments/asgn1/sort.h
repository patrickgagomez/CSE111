#pragma once

#include <functional>
#include <iostream>

namespace cse {
    
	template<typename Iter, typename Cmp = std::less<>>
    	void sort(Iter beg, Iter end, Cmp cmp = {}) {
		//loop through the elements in the iterator...
		for (Iter i = beg; i != end; i++){
			//loop through any following elements to compare them...
			for (Iter j = beg; j < i; j++){
				//if the first element being compared is less / greater (user choice)
				//then we swap them. Comparing every element (j) to the first element (i)
				//ensures the array stays in order.
				if (cmp(*i, *j)){
					std::iter_swap(i,j);
				}
			}		
		}
	}
}
