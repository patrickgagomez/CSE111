//THIS .CPP IS A PERSONAL TESTING SPACE
#include "sort.h"
#include <stdio.h>
#include <iostream>
#include <vector>

int main(void){
		

	//created an array with numbers bigger than 1,2,3,etc...
	int arr[] = {109238, 21123, 1873917, 1203701, 120993812};


	//looped through the array and printed it, could definitely be a function...
	for (auto *iter = arr; iter != arr + (sizeof(arr)/sizeof(arr[0])); ++iter){
		std::cout << " " <<*iter;
	}
	std::cout << "\n";


	//sorted the array
	cse::sort(std::begin(arr), std::end(arr), std::greater());


	//print it out again (function, I know)
	for (auto *iter = arr; iter != arr + (sizeof(arr)/sizeof(arr[0])); ++iter){
		std::cout << " " <<*iter;
	}
	std::cout << "\n";


	//if it is correctly sorted, the std function (is_sorted) will tell us and print out
	//the result!
	if (std::is_sorted(std::cbegin(arr), std::cend(arr))){
		std::cout << "sorted!\n";
	}


	//this code was the first attempt I made originally using a vector, realized we needed to
	//use an array, but wanted to keep this here for reference in the future? mostly for funsies!

	/*
	std::vector<int> vec (arr, arr + sizeof(arr) / sizeof(int) );
	for (std::vector<int>::iterator it = vec.begin();it != vec.end(); ++it)
		std::cout << " " << *it;
	std::cout << std::endl;

	cse::sort(vec.begin(), vec.end(), std::greater());

	for (std::vector<int>::iterator it = vec.begin();it != vec.end(); ++it)
	     	std::cout << " " << *it;  
	std::cout << std::endl;		
	*/
	//
	//
	//

	return 0;
}
