#include "grid.h"
#include <iostream>
#include <fstream>

using namespace std;

int main(void){
	Grid G(30, 37);

	G.setEdge({0,0},{1,0},15);
	G.setEdge({0,0},{0,1},22);
	G.setEdge({1,0},{1,1},97);
	G.setEdge({0,1},{1,1},13);

	ofstream testfile;
	testfile.open("testSER.txt");
	G.serialize(testfile);
	testfile.close();
	G.serialize(std::cout);

	cout << "____________________________" << endl;

	cout << "Current height: "<< G.getHeight() << endl;
	cout << "Current width : "<< G.getWidth()  << endl;

	cout << "____________________________" << endl;

	cout << "Weight of line between point (1,0) and (1,1): " << G.getEdge({1,0},{1,1}) << endl;

	cout << "____________________________" << endl;

	ofstream myfile;
	myfile.open ("test.ppm");
	G.draw(myfile);
	G.draw(std::cout);
	myfile.close();

	cout << "____________________________" << endl;

	
	ifstream otherfile("testSER.txt");
	Grid G2 = Grid::load(otherfile);
	otherfile.close();

	ofstream newfile;
	newfile.open ("newSER.txt");
	G2.serialize(newfile);
	newfile.close();

	return 0;
}

// x CONSTRUCTOR
// x GETHEIGHT
// x GETWIDTH
// x GETEDGE
// x SETEDGE
// x DRAW <--------fixed
// x SERIALIZE
// o LOAD

