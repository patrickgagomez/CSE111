#include "grid.h"

#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <cassert>

// Constants ---------------------------------------------------------
Grid::weight_t const Grid::NOEDGE = -1;
Grid::weight_t const Grid::PATH = 1;
std::string const P3_NODE = "255 255 255\n";
std::string const P3_EDGE = "255 255 255\n";
std::string const P3_WALL = "0 0 0\n";
std::string const P3_PATH = "255 0 0\n";

// Definitions -------------------------------------------------------
std::ostream& operator<<(std::ostream &out, Point const &p) {
    return out << '(' << p.x << ',' << p.y << ')';
}

Grid::Node::Node() {
    weights[Node::RIGHT] = NOEDGE;
    weights[Node::DOWN] = NOEDGE;
}

Grid::Grid(unsigned height, unsigned width)
{
	nodes_.resize(width);
	for (unsigned i = 0; i < width; i++){
		nodes_[i].resize(height);
	}
	/*
	Node n;
	std::vector<Grid::Node> row (width, n);
	for (unsigned i = 0; i < height; i++){
		nodes_.push_back(row);
	}
	*/
}

unsigned Grid::getHeight() const {
	return nodes_[0].size();
}

unsigned Grid::getWidth() const {
	return nodes_.size();
}

Grid::weight_t Grid::getEdge(Point const &a, Point const &b) const {
	const unsigned x1 = a.x;
	const unsigned y1 = a.y;
	const unsigned x2 = b.x;
	const unsigned y2 = b.y;
	Node n;

	if (x1 == x2 && y1 == y2){
		return 0;
	}

	if (y1 == y2){
		//purple
		if (x1 < x2){
			n = nodes_[x1][y1];
			return n.weights[Node::RIGHT];

			//orange
		} else if (x1 > x2){
			n = nodes_[x2][y2];
			return n.weights[Node::RIGHT];	
		}	
	} 
	
	else if (x1 == x2){
		//pink
		if (y1 < y2){
			n = nodes_[x1][y1];
			return n.weights[Node::DOWN];

			//blue
		} else if (y1 > y2){
			n = nodes_[x2][y2];
			return n.weights[Node::DOWN];
		}
	}

	return NOEDGE;
}

bool Grid::setEdge(Point const &a, Point const &b, weight_t weight) {
	unsigned x1 = a.x;
	unsigned y1 = a.y;
	unsigned x2 = b.x;
	unsigned y2 = b.y;
	
	if (x1 > getWidth() || x2 > getWidth()){
		return false;
	}
	if (y1 > getHeight() || y2 > getHeight()){
		return false;
	}

	if (x1 == x2 && y1 == y2){
		return false;
	}

	if (y1 == y2){
		if (x1 < x2){
			nodes_[x1][y1].weights[Node::RIGHT] = weight;
			return true;
		} else if (x1 > x2){
			nodes_[x2][y2].weights[Node::RIGHT] = weight;
			return true;
		}
	}

	else if (x1 == x2){
		if (y1 < y2){
			nodes_[x1][y1].weights[Node::DOWN] = weight;
			return true;
		} else if (y1 > y2){
			nodes_[x2][y2].weights[Node::DOWN] = weight;
			return true;
		}
	}

	return false;
}

void Grid::draw(std::ostream &out) const {
	const unsigned ySize = (getHeight() * 2) + 1;
	const unsigned xSize = (getWidth() * 2) + 1;

	const unsigned regY = getHeight();
	const unsigned regX = getWidth();
	const unsigned maxColVal = 255;

	out << "P3" << std::endl << xSize << " " << ySize << std::endl << maxColVal << std::endl;

	for (unsigned i = 0; i < xSize; i++){
		out << P3_WALL;	
	}
	//out << std::endl;

	for(unsigned l = 1; l < (regY); l++){
		//out << "<----------------------LOOP L START: " << l << std::endl;
		out << P3_WALL;
		for(unsigned j = 0; j < (regX-1); j++){
			//out << "<----------------------LOOP J START: " << j << std::endl;
			out << P3_NODE;
			out << P3_EDGE;
			//out << "<----------------------LOOP J END:   " << j << std::endl;
		}
		out << P3_NODE;
		out << P3_WALL;

		//out << std::endl;

		out << P3_WALL;
		for(unsigned k = 0; k < (regX-1); k++){
			//out << "<----------------------LOOP K START: " << k << std::endl;
			out << P3_EDGE;
			out << P3_WALL;
			//out << "<----------------------LOOP K END:   " << k << std::endl;
		}
		out << P3_EDGE;
		out << P3_WALL;

		//out << std::endl;
		//out << "<----------------------LOOP L END:   " << l << std::endl;
		//out << "<----------------------END REGY V:   " << regY << std::endl;
	}

	out << P3_WALL;
	for (unsigned z = 0; z < (regX-1); z++){
		//out << "<----------------------LOOP Z START: " << z << std::endl;
		out << P3_NODE;
		out << P3_EDGE;
		//out << "<----------------------LOOP Z END:   " << z << std::endl;
	}
	out << P3_NODE;
	out << P3_WALL;
	
	//out << std::endl;

	for (unsigned n = 0; n < xSize;n++){
		out << P3_WALL;
	}



	/*
	unsigned ySize = (nodes_.size() * 2) + 1;
	unsigned xSize = (nodes_[0].size() * 2) + 1;
	unsigned maxColVal = 255;

	out << "P3" << std::endl << xSize << " " << ySize << std::endl << maxColVal << std::endl;

	//top of black border
	for (unsigned i = 0; i < xSize; i++){
		out << P3_WALL;	
	}

	out << std::endl;

	unsigned tarLoop = nodes_.size();
	out << "TARLOOP:" << tarLoop << std::endl;

	for (unsigned j = 0; j < tarLoop; j++){
		out << "POINT BLOCK:" << std::endl;
		out << P3_WALL;
		unsigned tar = nodes_[0].size() - 1;
		out << "TAR: " << tar << std::endl;
		for (unsigned i = 0; i < tar; i++){
			out << P3_NODE;
			out << P3_EDGE;
		}
		out << P3_NODE;
		out << P3_WALL;

		out << std::endl;

		out << "EDGE BLOCK:" << std::endl;
		out << P3_WALL;
		for (unsigned k = 0; k < tar; k++){
			out << P3_EDGE;
			out << P3_WALL;
		}
		out << P3_EDGE;
		out << P3_WALL;

		out << std::endl;
	}

	for (unsigned i = 0; i < xSize; i++){
		out << P3_WALL;
	}
	out << std::endl;
	*/
}

void Grid::serialize(std::ostream &out) const {

	const unsigned x = getWidth();
	const unsigned y = getHeight();
	out << x << " " << y << std::endl;
		
	for (unsigned i = 0; i < y; i++){
		for (unsigned j = 0; j < x; j++){
			unsigned x2 = j + 1;
			unsigned y2 = i + 1;

			//printing to the right
			if (x2 < getWidth()){
				out << "(" << j << "," << i << ")" << getEdge({j, i}, {x2, i}) << "(" << x2 << "," << i << ")\n";
			}
			//printing downwards
			if (y2 < getHeight()){
				out << "(" << j << "," << i << ")" << getEdge({j, i}, {j, y2}) << "(" << j << "," << y2 << ")\n";
			}
		}	
	}	
}

Grid Grid::load(std::istream &in) {
	unsigned x1, y1, x2, y2;
	unsigned x, y;
	weight_t dist;

	std::string line;
	std::getline(in, line);

	int scanRes = sscanf(line.c_str(), "%u %u\n", &x, &y);
	if (scanRes != 2){
		std::cout << "not enough vars for x and y\n";
	}

	Grid G(y,x);
	
	//Grid G(x,y);
	//std::cout << "WIDTH: " << G.getWidth() << std::endl << "HEIGHT: " << G.getHeight() << std::endl;

	while (!in.eof()){
		std::getline(in, line);
		scanRes = sscanf(line.c_str(), "(%u,%u)%u(%u,%u)\n", &x1, &y1, &dist, &x2, &y2);
		/*
		if (scanRes != 5){
			std::cout << "not enough vars to set edges\n";
		}
		*/
		//std::cout << "EDGE: " << x1 << "," << y1 << " - " << x2 << "," << y2 << ".....";
		G.setEdge({x1, y1},{x2,y2},dist);
		//std::cout << "SET!\n";
	}

	return G;
}
