#include <iostream>
#include <fstream>
#include <getopt.h>
#include <queue>

#include "grid.h"
#include "util.h"

using namespace std;

std::string usage();

// USED FOR PQ //////////////////////////////////////////////////
//CITATION: https://www.geeksforgeeks.org/stl-priority-queue-for-structure-or-class/
struct pqPoint {
	Point p {};
	unsigned dist {};

	pqPoint(Point const &p, unsigned d)
			: p(p), dist(d)
	{
	}
};

struct CompareDist {
	bool operator()(pqPoint const &p1, pqPoint const& p2)
	{
		//CHANGE SIGN FOR OG
		return p1.dist > p2.dist;
	}
};
/////////////////////////////////////////////////////////////////

#define OPTS "i:o:p:h"

int main(int const argc, char *argv[]) {
    exec::execname(argv[0]);
    
    // Options
    std::string outfile = "-";
    std::string infile = "-";
    std::string ppmName = "-";	
	bool c_ppm = false;

    // Getopts
    int opt;
    while ((opt = getopt(argc, argv, OPTS)) != -1) {
        switch (opt) {
	        case 'i': infile = optarg; break;
            case 'o': outfile = optarg; break;
            case 'p': c_ppm = true; ppmName = optarg; break;
            case 'h': std::cout << usage(); return 0;
            default: std::cerr << usage(); return 1;
        }
    }


	Grid G(0,0);
	if (infile == "-"){
		G = Grid::load(std::cin);
	} else if (infile.length() > 0){
		std::ifstream in {infile};
		G = Grid::load(in);
		in.close();
	}

	unsigned width = G.getWidth();
	unsigned height = G.getHeight();

	Grid newG(height, width);
	
	//////////////////////////////////////////////////

	vector <bool> row (width, false);
	vector<vector<bool>> visited (height, row);

	vector <unsigned> cost ((width * height), -1);

	vector <Point> mstSet ((width * height), {0,0});

	priority_queue <pqPoint, vector<pqPoint>, CompareDist> pq;

	//////////////////////////////////////////////////

	unsigned index = 0;
	
	pqPoint p({0,0}, 0);
	pq.push(p);


	while (!pq.empty()){
		Point p = pq.top().p;
		unsigned dist = pq.top().dist;
		
		pq.pop();

		unsigned x = p.x;
		unsigned y = p.y;

		if (visited[x][y] == false){
			visited[x][y] = true;
			cost[index] = dist;
			mstSet[index] = {x, y};
			++index;

			Point a = {x,y};
			//GET THE RIGHT VAL
			Point b = {(x+1),y};

			if (x != (width - 1)){
				unsigned right = G.getEdge(a, b);
				pqPoint r(b, right);
				pq.push(r);
			}

			//CHECK IF WE CAN GET THE LEFT VAL
			if (x != 0){
				b = {(x-1), y};
				unsigned left = G.getEdge(a, b);
				pqPoint l(b, left);
				pq.push(l);
			}

			//GET THE DOWN VAL
			if (y != (height - 1)){
				b = {x, (y+1)};
				unsigned down = G.getEdge(a, b);
				pqPoint d(b, down);
				pq.push(d);
			}

			//CHECK IF WE CAN GET THE UP VAL
			if (y != 0){
				b = {x, (y-1)};
				unsigned up = G.getEdge(a, b);
				pqPoint u(b, up);
				pq.push(u);
			}

		}
	}


	newG.setEdge(mstSet[0], mstSet[1],cost[1]);

	for (unsigned i = 1; i < mstSet.size(); i++){
		//if (cost[i] != -1) <-- ORIGINAL
		if (cost[i] > 0){
			Point check = mstSet[i];
			unsigned xC = check.x;
			unsigned yC = check.y;

			Grid::weight_t right = -1;
			Grid::weight_t left = -1;
			Grid::weight_t up = -1;
			Grid::weight_t down = -1;
	
			//RIGHT
			right = G.getEdge(check, {xC+1, yC});
			//DOWN
			down = G.getEdge(check, {xC, yC+1});
			//LEFT
        	if (xC != 0 || xC != width - 1){ left = G.getEdge(check, {xC-1, yC}); }
			//UP
        	if (yC != 0 || yC != height - 1){ up = G.getEdge(check, {xC, yC-1}); }
		
			//////////////////////////////////////////////////////////////////////////////////////
		
			if (right == cost[i]){
				newG.setEdge(check, {xC+1, yC}, cost[i]);
			}

			if (left == cost[i]){
				newG.setEdge(check, {xC-1, yC}, cost[i]);
			}

			if (up == cost[i]){              
				newG.setEdge(check, {xC, yC-1}, cost[i]);
			}

			if (down == cost[i]){              
				newG.setEdge(check, {xC, yC+1}, cost[i]);
			}
		}
	}

	//newG.serialize(std::cout);

	if (c_ppm){
		ofstream ppmfile;
		if (ppmName != "-"){
			ppmfile.open ({ppmName});
		} else {
			ppmfile.open ("img.ppm");
		}
		newG.draw(ppmfile);
		ppmfile.close();
	}

	ofstream out;
	if (outfile != "-"){
		out.open ({outfile});
	} else {
		newG.serialize(std::cout);
		out.close();
	}
	newG.serialize(out);
	out.close();

    return exec::status();
}

std::string usage() {
    return std::string{}
        + "SYNOPSIS\n"
        + "     Given a randomized \"grid-graph\", generate a maze by creating a\n"
        + " minimum spanning tree\n"
        + "\n"
        + "USAGE\n"
        + "     " + exec::execname() + " [-" + OPTS + "]\n"
        + "\n"
        + "OPTIONS\n"
        + "     -i infile           input file with serialized grid data [default: stdin]\n"
        + "     -o outfile          maze output in serialized form [default: stdout]\n"
        + "     -p img.ppm          generate ppm image of maze\n"
        + "     -h                  Print out helpful information\n"
        ;
}
