#include <iostream>
#include <fstream>
#include <getopt.h>
#include <queue>

#include "grid.h"
#include "util.h"

std::string usage();

using namespace std;

#define OPTS "i:o:s:e:p:h"

int main (int const argc, char *argv[]) {
    exec::execname(argv[0]);

	unsigned x1 = 0;
   	unsigned y1 = 0;
    unsigned x2 = 0; 
	unsigned y2 = 0;
	std::string outfile = "-";
	std::string infile = "-";
	std::string ppmName = "-";  
	bool c_ppm = false;

	// Getopts
    int opt;
    while ((opt = getopt(argc, argv, OPTS)) != -1) {
        switch (opt) {
	        case 'i': infile = optarg; break;
            case 'o': outfile = optarg; break;
            case 's': x1 = optarg[0]; y1 = optarg[2]; break;
	        case 'e': x2 = optarg[0]; y2 = optarg[2]; break;
	        case 'p': c_ppm = true; ppmName = optarg; break;
            case 'h': std::cout << usage(); return 0;
            default: std::cerr << usage(); return 1;
        }
    }

    Grid G(0,0);
	if (infile == "-"){
		G = Grid::load(std::cin);
	} else if (infile.length() > 0){
		std::ifstream in {infile};
		G = Grid::load(in);
		in.close();
	}

	
	const unsigned width = G.getWidth();
	const unsigned height = G.getHeight();


	Point start{x1, y1};
	Point end{0,0};
	if (x2 == 0 || y2 == 0){
		end = {(width-1),(height-1)};
	} else {
		end = {x2, y2};
	}


	Point dummy{99999, 99999};
	vector<Point> rowData (4, dummy);
	vector<vector<Point>> row (width, rowData);
	vector<vector<vector<Point>>> adj (height, row);

	//CREATE ADJ LIST
	for (unsigned i = 0; i < height; i++){
    	for (unsigned j = 0; j < width; j++){
        	unsigned x2 = j + 1;
            unsigned y2 = i + 1;

            unsigned edgeW;
			Point a{0,0};
			Point b{0,0};
            if (x2 < G.getWidth()){
            	edgeW = G.getEdge({j, i}, {x2, i});
                if (edgeW != Grid::NOEDGE){
					a = {j, i};
					b = {x2, i};
					adj[j][i][0] = b;
					adj[x2][i][2] = a;	
                }
            }
          	if (y2 < G.getHeight()){
            	edgeW = G.getEdge({j, i}, {j, y2});
            	if (edgeW != Grid::NOEDGE){
                	a = {j, i};
					b = {j, y2};
					adj[j][i][1] = b;
					adj[j][y2][3] = a;	
				}
           	}
        }
    }


	//UNCOMMENT FOR PRINTING ADJ LIST
	/*
	for (unsigned y = 0; y < height; y++){
		for (unsigned x = 0; x < width; x++){
			for (unsigned i = 0; i < 4; i++){
				if (adj[x][y][i] != dummy){
					cout << x << ", " << y << " ---> " << adj[x][y][i] << endl;
				}
			}
			cout << endl;
		}
	}
	*/

	vector<vector<Point>> result;

	queue<vector<Point>> q;
	vector<Point> vStart = { start };
	q.push(vStart);

	while (!q.empty()){
		vector<Point> path = q.front();
		q.pop();
		Point lastNode = path.at(path.size() - 1);
		if (lastNode == end){
			result.push_back(path);
			break;			
		} else {
			vector<Point> n;
			unsigned lnX = lastNode.x;
			unsigned lnY = lastNode.y;
			for (unsigned i = 0; i < 4; i++){
				if (adj[lnX][lnY][i] != dummy){
					n.push_back(adj[lnX][lnY][i]);
				}
			}
			for (Point j : n){
				vector<Point> list = path;
				list.push_back(j);
				q.push(list);
			}
		}
	}

	vector<Point> finalResult = result[0];
	for (unsigned i = 1; i < finalResult.size(); i++){
		G.setEdge(finalResult[i-1], finalResult[i], Grid::PATH);	
	}

	if (c_ppm){
		ofstream ppmfile;
    	if (ppmName != "-"){
    		ppmfile.open ({ppmName});
        } else {
        	ppmfile.open("img.ppm");
        }

        G.draw(ppmfile);     
	    ppmfile.close();
    }

	if (infile != "-"){
		ofstream out;
		out.open({outfile});
		G.serialize(out);     
		out.close();
	} else {
		G.serialize(std::cout);
	}
	
    return exec::status();
}

std::string usage() {
    return std::string{}
        + "SYNOPSIS\n"
        + "     Find the path between two points in a maze\n"
        + "\n"
        + "USAGE\n"
        + "     " + exec::execname() + " [-" + OPTS + "]\n"
        + "\n"
        + "OPTIONS\n"
        + "     -i input.dat        input file with serialized data [default: stdin]\n"
        + "     -o outfile.dat      output file in serialized form [default: stdout]\n"
        + "     -s x:y              starting point for finding path [default: 0:0]\n"
        + "     -e x:y              ending point for finding path [default: bottom right]\n"
        + "     -p img.ppm          generate ppm image of solved maze\n"
        + "     -h                  Print out helpful information\n"
        ;
}
