#include <cstdlib>
#include <exception>
#include <iostream>
#include <regex>
#include <string>
#include <unistd.h>
#include <fstream>

using namespace std;

#include "avl.h"
#include "util.h"
#include "debug.h"

using str_str_map = AVLTree<string,string>;
using str_str_pair = str_str_map::value_type;

void scan_options (int argc, char** argv) {
   opterr = 0;
   for (;;) {
      int option = getopt (argc, argv, "@:");
      if (option == EOF) break;
      switch (option) {
         case '@':
            debugflags::setflags (optarg);
            break;
         default:
            complain() << "-" << char (optopt) << ": invalid option"
                       << endl;
            break;
      }
   }
}

int main (int argc, char** argv) {
   
   sys_info::execname (argv[0]);
   scan_options (argc, argv);

    std::regex comment("(^#.*)");
    std::regex set("([A-Za-z1-9]+) = ([A-Za-z1-9]+)");
    std::regex print("=");
    std::regex printVal("(=) ([A-Za-z1-9])+");
    std::regex find("([A-Za-z1-9])+");

    int line;
    string read;
    for (int i = 1; i != argc; ++i){
        ifstream in;
        in.open(argv[1]);
        line = 0;

        std::smatch match, match2, match3, match4, match5;
        getline(in, read);
        std::regex_search(read, match, comment);
        std::regex_search(read, match2, set);
        std::regex_search(read, match3, print);
        std::regex_search(read, match4, printVal);
        std::regex_search(read, match5, find);

        string matchStr = match.str(1);
        if (matchStr[0] == '#'){
            cout << "1" << endl;
            cout << matchStr << endl;
        }

        if (match2.size() == 2){
            cout << "2" << endl;
            cout << match2.str(1) << match2.str(2) << endl;
        }
        
        matchStr = match3.str(1);
        if (matchStr[0] == '='){
            cout << "3" << endl;
            cout << matchStr << endl;
        }

        matchStr = match4.str(1);
        string matchStr2 = match4.str(2);
        if (matchStr[0] == '=' && matchStr2.length() > 0){
            cout << "4" << endl;
            cout << match4.str(1) << match4.str(2) << endl;
        }

        matchStr = match5.str(1);
        if (matchStr.length() > 0){
            cout << "5" << endl;
            cout << match5.str(1);
        }


        in.close();
        ++line;
    }

   /* 
    AVLTree<int, int> map;
    auto iter = map.insert({1, 2});
    cout << iter->second << endl;

    map.insert({214,156});
    map.insert({2,6});
    map.insert({4,2});

    auto iter2 = map.insert({411, 2215});
    cout << iter2->second << endl;

    AVLTree<int,int>::iterator itor = map.begin();
    cout << itor->first << " " << itor->second << endl;
   
    str_str_map test;
    for (char** argp = &argv[optind]; argp != &argv[argc]; ++argp) {
       str_str_pair pair (*argp, to_string<int> (argp - argv));
       cout << "Before insert: " << pair << endl;
       test.insert (pair);
    }
    test.insert({"yo","greeting"});
    test.insert({"bye","farewell"});
    test.insert({"wazzup", "greeting"});

   
    cout << test.empty() << endl;
    for (str_str_map::iterator itor = test.begin();
         itor != test.end(); ++itor) {
       cout << "During iteration: " << *itor << endl;
    }

    str_str_map::iterator itor = test.begin();
    test.erase(itor);
    */

   cout << "EXIT_SUCCESS" << endl;
   return EXIT_SUCCESS;
}

