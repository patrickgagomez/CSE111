#include "Polygon.h"
#include "Geom.h"
#include "Reuleaux.h"
#include <gtest/gtest.h>

TEST(PolygonReuleaux, Contained)
{
    Point verts[3] = { Point(2.2,2.1), Point(4,1) , Point(2.2,0) };
    ReuleauxTriangle outer = ReuleauxTriangle(verts);

    std::vector<Point> pointsInner { Point(2.5,1.5), 
                                     Point(3,1.5), 
                                     Point(3.5,1), 
                                     Point(2.5,1) };
    Polygon inner = Polygon(pointsInner);

    ASSERT_TRUE(inner.ContainedBy(outer));
}

TEST(PolygonReuleaux, Outside)
{
    Point verts[3] = { Point(2.2,2.1), Point(4,1) , Point(2.2,0) };
    ReuleauxTriangle outer = ReuleauxTriangle(verts);

    std::vector<Point> pointsInner { Point(12.5,1.5), 
                                     Point(13,1.5), 
                                     Point(13.5,1), 
                                     Point(12.5,1) };
    Polygon inner = Polygon(pointsInner);

    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonReuleaux, Surrounds)
{
    Point verts[3] = { Point(2.2,2.1), Point(4,1) , Point(2.2,0) };
    ReuleauxTriangle outer = ReuleauxTriangle(verts);

    std::vector<Point> pointsInner { Point(1.5,2.5), 
                                     Point(4.5,2.5), 
                                     Point(4.5,-0.5), 
                                     Point(1,-0.5) };
    Polygon inner = Polygon(pointsInner);

    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonReuleaux, Intersects)
{
    Point verts[3] = { Point(2.2,2.1), Point(4,1) , Point(2.2,0) };
    ReuleauxTriangle outer = ReuleauxTriangle(verts);

    std::vector<Point> pointsInner { Point(1,1.5), 
                                     Point(3,1.5), 
                                     Point(3.5,1), 
                                     Point(1,1) };
    Polygon inner = Polygon(pointsInner);

    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonReuleaux, TouchesInside)
{
    Point verts[3] = { Point(0,1.7), Point(1,0) , Point(-1,0) };
    ReuleauxTriangle outer = ReuleauxTriangle(verts);

    std::vector<Point> pointsInner { Point(-0.3,1.4), 
                                     Point(0.2,1.4), 
                                     Point(0.2,0.3), 
                                     Point(-1,0.3) };
    Polygon inner = Polygon(pointsInner);

    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonReuleaux, TouchesOutside)
{
    Point verts[3] = { Point(2.2,2.1), Point(4,1) , Point(2.2,0) };
    ReuleauxTriangle outer = ReuleauxTriangle(verts);

    std::vector<Point> pointsInner { Point(2.2,1.5), 
                                     Point(0,1.5), 
                                     Point(0,1), 
                                     Point(2.2,1) };
    Polygon inner = Polygon(pointsInner);

    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonReuleaux, Coincident)
{
    Point verts[3] = { Point(2.2,2.1), Point(4,1) , Point(2.2,0) };
    ReuleauxTriangle outer = ReuleauxTriangle(verts);

    std::vector<Point> pointsInner { Point(2.2,2.1), 
                                     Point(4,1), 
                                     Point(3.3,0.6), 
                                     Point(2.2,0) };
    Polygon inner = Polygon(pointsInner);

    ASSERT_FALSE(inner.ContainedBy(outer));
}

/* 
   You'll need to extend this by adding additional tests for:
    1. Inner and Outer intersect (not contained)
    2. Inner is entirely outside Outer (not contained)
    3. Inner surrounds Outer (not contained)
    3. Inner coincident with Outer (not contained)
    4. Inner perimeter touches Outer perimeter, Inner is inside Outer (not contained)
    5. Inner perimeter touches Outer perimeter, Inner is outside Outer (not contained)

    Note that 4. and 5. should be taken care of by 1. but you need the tests to make sure
*/
