#include "Geom.h"
#include "Polygon.h"
#include "Circle.h"
#include <gtest/gtest.h>
#include <vector>

TEST(PolygonCircle, Contained)
{
    std::vector<Point> pointsInner { Point(5,6.5), 
                                     Point(7,6.5), 
                                     Point(7.5,4.5), 
                                     Point(5.5,4.5) };
    Polygon inner = Polygon(pointsInner);
    Circle outer = Circle(Point(6.0,6.0), 4);
    ASSERT_TRUE(inner.ContainedBy(outer));
}

TEST(PolygonCircle, Outside)
{
    std::vector<Point> pointsInner { Point(15,6.5), 
                                     Point(17,6.5), 
                                     Point(17.5,4.5), 
                                     Point(15.5,4.5) };
    Polygon inner = Polygon(pointsInner);
    Circle outer = Circle(Point(6.0,6.0), 4);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonCircle, Surrounds)
{
    std::vector<Point> pointsInner { Point(1,11), 
                                     Point(11,10), 
                                     Point(12,1), 
                                     Point(1,1) };
    Polygon inner = Polygon(pointsInner);
    Circle outer = Circle(Point(6.0,6.0), 4);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonCircle, Intersects)
{
    std::vector<Point> pointsInner { Point(5,6.5), 
                                     Point(7,6.5), 
                                     Point(7.5,4.5), 
                                     Point(5.5,4.5) };
    Polygon inner = Polygon(pointsInner);
    Circle outer = Circle(Point(8.3,3), 4);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonCircle, TouchesInside)
{
    std::vector<Point> pointsInner { Point(5,6.5), 
                                     Point(7,6.5), 
                                     Point(7.5,4.5), 
                                     Point(5.5,4.5) };
    Polygon inner = Polygon(pointsInner);
    Circle outer = Circle(Point(8.1,3.9), 4);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonCircle, TouchesOutside)
{
    std::vector<Point> pointsInner { Point(5,6.5), 
                                     Point(7,6.5), 
                                     Point(7.5,4.5), 
                                     Point(5.5,4.5) };
    Polygon inner = Polygon(pointsInner);
    Circle outer = Circle(Point(11.5,4), 4);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonCircle, Coincident)
{
    std::vector<Point> pointsInner { Point(5,6.5), 
                                     Point(7,6.5), 
                                     Point(7.5,4.5), 
                                     Point(5.5,4.5) };
    Polygon inner = Polygon(pointsInner);
    Circle outer = Circle(Point(6.3,5.5), 1.0);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

/* 
   You'll need to extend this by adding additional tests for:
    1. Inner and Outer intersect (not contained)
    2. Inner is entirely outside Outer (not contained)
    3. Inner surrounds Outer (not contained)
    3. Inner coincident with Outer (not contained)
    4. Inner perimeter touches Outer perimeter, Inner is inside Outer (not contained)
    5. Inner perimeter touches Outer perimeter, Inner is outside Outer (not contained)

    Note that 4. and 5. should be taken care of by 1. but you need the tests to make sure
*/
