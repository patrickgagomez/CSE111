#include "Geom.h"
#include "Polygon.h"
#include <gtest/gtest.h>
#include <vector>

TEST(PolygonPolygon, Contained)
{
    std::vector<Point> pointsOuter { Point(3, 7), 
                                     Point(8, 7), 
                                     Point(8,1), 
                                     Point(4,1), 
                                     Point(4,3), 
                                     Point(6,4), 
                                     Point(3,5) };

    std::vector<Point> pointsInner { Point(5,6.5), 
                                     Point(7,6.5), 
                                     Point(7.5,4.5), 
                                     Point(5.5,4.5) };
    Polygon outer = Polygon(pointsOuter);
    Polygon inner = Polygon(pointsInner);
    ASSERT_TRUE(inner.ContainedBy(outer));
}

TEST(PolygonPolygon, Outside)
{
    std::vector<Point> pointsOuter { Point(3, 7), 
                                     Point(8, 7), 
                                     Point(8,1), 
                                     Point(4,1), 
                                     Point(4,3), 
                                     Point(6,4), 
                                     Point(3,5) };

    std::vector<Point> pointsInner { Point(15,6.5), 
                                     Point(17,6.5), 
                                     Point(17.5,4.5), 
                                     Point(15.5,4.5) };
    Polygon outer = Polygon(pointsOuter);
    Polygon inner = Polygon(pointsInner);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonPolygon, Surrounds)
{
    std::vector<Point> pointsOuter { Point(3, 7), 
                                     Point(8, 7), 
                                     Point(8,1), 
                                     Point(4,1), 
                                     Point(4,3), 
                                     Point(6,4), 
                                     Point(3,5) };

    std::vector<Point> pointsInner { Point(2,8), 
                                     Point(9,8), 
                                     Point(9,0), 
                                     Point(1,0) };
    Polygon outer = Polygon(pointsOuter);
    Polygon inner = Polygon(pointsInner);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonPolygon, Intersects)
{
    std::vector<Point> pointsOuter { Point(3, 7), 
                                     Point(8, 7), 
                                     Point(8,1), 
                                     Point(4,1), 
                                     Point(4,3), 
                                     Point(6,4), 
                                     Point(3,5) };

    std::vector<Point> pointsInner { Point(4,8), 
                                     Point(6,8), 
                                     Point(7.5,4.5), 
                                     Point(5.5,4.5) };
    Polygon outer = Polygon(pointsOuter);
    Polygon inner = Polygon(pointsInner);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonPolygon, TouchesInside)
{
    std::vector<Point> pointsOuter { Point(3, 7), 
                                     Point(8, 7), 
                                     Point(8,1), 
                                     Point(4,1), 
                                     Point(4,3), 
                                     Point(6,4), 
                                     Point(3,5) };

    std::vector<Point> pointsInner { Point(4.2,7), 
                                     Point(5.6,7), 
                                     Point(7.5,4.5), 
                                     Point(5.5,4.5) };
    Polygon outer = Polygon(pointsOuter);
    Polygon inner = Polygon(pointsInner);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonPolygon, TouchesOutside)
{
    std::vector<Point> pointsOuter { Point(3, 7), 
                                     Point(8, 7), 
                                     Point(8,1), 
                                     Point(4,1), 
                                     Point(4,3), 
                                     Point(6,4), 
                                     Point(3,5) };

    std::vector<Point> pointsInner { Point(4,7), 
                                     Point(6,7), 
                                     Point(7.5,8.5), 
                                     Point(5.5,8.5) };
    Polygon outer = Polygon(pointsOuter);
    Polygon inner = Polygon(pointsInner);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(PolygonPolygon, Coincident)
{
    std::vector<Point> pointsOuter { Point(3, 7), 
                                     Point(8, 7), 
                                     Point(8,1), 
                                     Point(4,1), 
                                     Point(4,3), 
                                     Point(6,4), 
                                     Point(3,5) };
    Polygon outer = Polygon(pointsOuter);
    Polygon inner = Polygon(pointsOuter);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

/* 
   You'll need to extend this by adding additional tests for:
    1. Inner and Outer intersect (not contained)
    2. Inner is entirely outside Outer (not contained)
    3. Inner surrounds Outer (not contained)
    3. Inner coincident with Outer (not contained)
    4. Inner perimeter touches Outer perimeter, Inner is inside Outer (not contained)
    5. Inner perimeter touches Outer perimeter, Inner is outside Outer (not contained)

    Note that 4. and 5. should be taken care of by 1. but you need the tests to make sure
*/
