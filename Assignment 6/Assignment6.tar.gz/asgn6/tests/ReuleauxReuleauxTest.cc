#include "Circle.h"
#include "Geom.h"
#include "Reuleaux.h"
#include <gtest/gtest.h>

TEST(ReuleauxReuleaux, Contained)
{
    Point vertsOuter[3] = { Point(-1, 0), Point(0, 2) , Point(1.2, 0.1) };
    Point vertsInner[3] = { Point(-0.33, 0.53), Point(-0.1, 1) , Point(0.21, 0.54) };
    ReuleauxTriangle inner = ReuleauxTriangle(vertsInner);
    ReuleauxTriangle outer = ReuleauxTriangle(vertsOuter);
    ASSERT_TRUE(inner.ContainedBy(outer));
}

TEST(ReuleauxReuleaux, Outside)
{
    Point vertsOuter[3] = { Point(-1, 0), Point(0, 2) , Point(1.2, 0.1) };
    Point vertsInner[3] = { Point(-10.33, 0.53), Point(-10.1, 1) , Point(-9.79, 0.54) };
    ReuleauxTriangle inner = ReuleauxTriangle(vertsInner);
    ReuleauxTriangle outer = ReuleauxTriangle(vertsOuter);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxReuleaux, Surrounds)
{
    
    Point vertsOuter[3] = { Point(-0.33, 0.53), Point(-0.1, 1) , Point(0.21, 0.54) };
    Point vertsInner[3] = { Point(-1, 0), Point(0, 2) , Point(1.2, 0.1) };
    ReuleauxTriangle inner = ReuleauxTriangle(vertsInner);
    ReuleauxTriangle outer = ReuleauxTriangle(vertsOuter);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxReuleaux, Intersects)
{
    Point vertsOuter[3] = { Point(1,2.7), Point(2.2,0.8) , Point(0,0.7) };
    Point vertsInner[3] = { Point(-0.1, 0.53), Point(0.2, 0.5) , Point(-0.3,0.5) };
    ReuleauxTriangle inner = ReuleauxTriangle(vertsInner);
    ReuleauxTriangle outer = ReuleauxTriangle(vertsOuter);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxReuleaux, TouchesInside)
{
    Point vertsOuter[3] = { Point(-1, 0), Point(0, 2) , Point(1.2, 0.1) };
    Point vertsInner[3] = { Point(0.4,0.5), Point(0.7,-0.1) , Point(0.1,-0.3) };
    ReuleauxTriangle inner = ReuleauxTriangle(vertsInner);
    ReuleauxTriangle outer = ReuleauxTriangle(vertsOuter);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxReuleaux, TouchesOutside)
{
    Point vertsOuter[3] = { Point(-1, 0), Point(0, 2) , Point(1.2, 0.1) };
    Point vertsInner[3] = { Point(-0.8,1.5), Point(-0.5,1) , Point(-1,1) };
    ReuleauxTriangle inner = ReuleauxTriangle(vertsInner);
    ReuleauxTriangle outer = ReuleauxTriangle(vertsOuter);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxReuleaux, Coincident)
{
    Point vertsOuter[3] = { Point(-1, 0), Point(0, 2) , Point(1.2, 0.1) };
    ReuleauxTriangle inner = ReuleauxTriangle(vertsOuter);
    ReuleauxTriangle outer = ReuleauxTriangle(vertsOuter);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

/* 
   You'll need to extend this by adding additional tests for:
    1. Inner and Outer intersect (not contained)
    2. Inner is entirely outside Outer (not contained)
    3. Inner surrounds Outer (not contained)
    3. Inner coincident with Outer (not contained)
    4. Inner perimeter touches Outer perimeter, Inner is inside Outer (not contained)
    5. Inner perimeter touches Outer perimeter, Inner is outside Outer (not contained)

    Note that 4. and 5. should be taken care of by 1. but you need the tests to make sure
*/
