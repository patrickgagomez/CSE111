#include "Polygon.h"
#include "Geom.h"
#include "Reuleaux.h"
#include <gtest/gtest.h>

TEST(ReuleauxPolygon, Contained)
{
    Point vertsInner[3] = { Point(2.4,2.4), Point(2.8,2.0) , Point(2.2,1.9) };
    ReuleauxTriangle inner = ReuleauxTriangle(vertsInner);

    std::vector<Point> pointsOuter { Point(1,3.5), 
                                     Point(2.9,3.5), 
                                     Point(3.9,1.5), 
                                     Point(1.4,0.6) };
    Polygon outer = Polygon(pointsOuter);
    
    ASSERT_TRUE(inner.ContainedBy(outer));
}

TEST(ReuleauxPolygon, Outside)
{
    Point vertsInner[3] = { Point(12.4,2.4), Point(12.8,2.0) , Point(12.2,1.9) };
    ReuleauxTriangle inner = ReuleauxTriangle(vertsInner);

    std::vector<Point> pointsOuter { Point(1,3.5), 
                                     Point(2.9,3.5), 
                                     Point(3.9,1.5), 
                                     Point(1.4,0.6) };
    Polygon outer = Polygon(pointsOuter);
    
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxPolygon, Surrounds)
{
    Point vertsInner[3] = { Point(2.4,2.4), Point(2.8,2.0) , Point(2.2,1.9) };
    ReuleauxTriangle inner = ReuleauxTriangle(vertsInner);

    std::vector<Point> pointsOuter { Point(2.3,2.2), 
                                     Point(2.5,2.2), 
                                     Point(2.6,2), 
                                     Point(2.3,2) };
    Polygon outer = Polygon(pointsOuter);
    
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxPolygon, Intersects)
{
    Point vertsInner[3] = { Point(2.4,2.4), Point(2.8,2.0) , Point(2.2,1.9) };
    ReuleauxTriangle inner = ReuleauxTriangle(vertsInner);

    std::vector<Point> pointsOuter { Point(1,3.5), 
                                     Point(1.9,3.2), 
                                     Point(2.8,1.9), 
                                     Point(1.4,0.6) };
    Polygon outer = Polygon(pointsOuter);
    
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxPolygon, TouchesInside)
{
    Point vertsInner[3] = { Point(2.4,2.4), Point(2.8,2.0) , Point(2.2,1.9) };
    ReuleauxTriangle inner = ReuleauxTriangle(vertsInner);

    std::vector<Point> pointsOuter { Point(1,3.5), 
                                     Point(2.2,2.9), 
                                     Point(2.8,1.9), 
                                     Point(1.4,0.6) };
    Polygon outer = Polygon(pointsOuter);
    
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxPolygon, TouchesOutside)
{
    Point vertsInner[3] = { Point(2.4,2.4), Point(2.8,2.0) , Point(2.2,1.9) };
    ReuleauxTriangle inner = ReuleauxTriangle(vertsInner);

    std::vector<Point> pointsOuter { Point(1,3.5), 
                                     Point(2.2,2.9), 
                                     Point(2.2,1.7), 
                                     Point(1.4,0.6) };
    Polygon outer = Polygon(pointsOuter);
    
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxPolygon, Coincident)
{
    Point vertsInner[3] = { Point(2.4,2.4), Point(2.8,2.0) , Point(2.2,1.9) };
    ReuleauxTriangle inner = ReuleauxTriangle(vertsInner);

    std::vector<Point> pointsOuter { Point(2.4,2.4), 
                                     Point(2.8,2.0), 
                                     Point(2.5,1.8), 
                                     Point(2.2,1.9) };
    Polygon outer = Polygon(pointsOuter);
    
    ASSERT_FALSE(inner.ContainedBy(outer));
}


/* 
   You'll need to extend this by adding additional tests for:
    1. Inner and Outer intersect (not contained)
    2. Inner is entirely outside Outer (not contained)
    3. Inner surrounds Outer (not contained)
    3. Inner coincident with Outer (not contained)
    4. Inner perimeter touches Outer perimeter, Inner is inside Outer (not contained)
    5. Inner perimeter touches Outer perimeter, Inner is outside Outer (not contained)

    Note that 4. and 5. should be taken care of by 1. but you need the tests to make sure
*/
