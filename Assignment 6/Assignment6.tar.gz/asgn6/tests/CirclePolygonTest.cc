#include "Circle.h"
#include "Polygon.h"
#include "Geom.h"
#include <gtest/gtest.h>
#include <vector>

// Uncomment when you're ready
TEST(CirclePolygon, Contained)
{
    std::vector<Point> pointsOuter { Point(5,6.5), 
                                     Point(7,6.5), 
                                     Point(7.5,4.5), 
                                     Point(5.5,4.5) };
    Polygon outer = Polygon(pointsOuter);
    Circle inner = Circle(Point(6.0,5.5), 0.5);
    ASSERT_TRUE(inner.ContainedBy(outer));
}

TEST(CirclePolygon, Outside)
{
    std::vector<Point> pointsOuter { Point(3.5,4.8), 
                                     Point(5.1,2.5), 
                                     Point(3.4,0.3), 
                                     Point(0.7,1.2),
                                     Point(0.8,4.1) };
    Polygon outer = Polygon(pointsOuter);
    Circle inner = Circle(Point(10.0,10.0), 2);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(CirclePolygon, Surrounds)
{
    std::vector<Point> pointsOuter { Point(3.5,4.8), 
                                     Point(5.1,2.5), 
                                     Point(3.4,0.3), 
                                     Point(0.7,1.2),
                                     Point(0.8,4.1) };
    Polygon outer = Polygon(pointsOuter);
    Circle inner = Circle(Point(2.7,2.6), 5);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(CirclePolygon, Intersects)
{
    std::vector<Point> pointsOuter { Point(3.5,4.8), 
                                     Point(5.1,2.5), 
                                     Point(3.4,0.3), 
                                     Point(0.7,1.2),
                                     Point(0.8,4.1) };
    Polygon outer = Polygon(pointsOuter);
    Circle inner = Circle(Point(4.0,2.4), 1.7);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(CirclePolygon, TouchesInside)
{
    std::vector<Point> pointsOuter { Point(3.5,4.8), 
                                     Point(5.1,2.5), 
                                     Point(3.4,0.3), 
                                     Point(0.7,1.2),
                                     Point(0.8,4.1) };
    Polygon outer = Polygon(pointsOuter);
    Circle inner = Circle(Point(2.9,2.7), 1.7);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(CirclePolygon, TouchesOutside)
{
    std::vector<Point> pointsOuter { Point(3.5,4.8), 
                                     Point(5.1,2.5), 
                                     Point(3.4,0.3), 
                                     Point(0.7,1.2),
                                     Point(0.8,4.1) };
    Polygon outer = Polygon(pointsOuter);
    Circle inner = Circle(Point(5.9,4.5), 1.7);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(CirclePolygon, Coincident)
{
    std::vector<Point> pointsOuter { Point(3.5,4.8), 
                                     Point(5.1,2.5), 
                                     Point(3.4,0.3), 
                                     Point(0.7,1.2),
                                     Point(0.8,4.1) };
    Polygon outer = Polygon(pointsOuter);
    Circle inner = Circle(Point(2.7,2.6), 2.0);
    ASSERT_FALSE(inner.ContainedBy(outer));
}
/* 
   You'll need to extend this by adding additional tests for:
    1. Inner and Outer intersect (not contained)
    2. Inner is entirely outside Outer (not contained)
    3. Inner surrounds Outer (not contained)
    3. Inner coincident with Outer (not contained)
    4. Inner perimeter touches Outer perimeter, Inner is inside Outer (not contained)
    5. Inner perimeter touches Outer perimeter, Inner is outside Outer (not contained)

    Note that 4. and 5. should be taken care of by 1. but you need the tests to make sure
*/
