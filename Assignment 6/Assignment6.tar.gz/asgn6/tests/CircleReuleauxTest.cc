#include "Circle.h"
#include "Geom.h"
#include "Reuleaux.h"
#include <gtest/gtest.h>

TEST(CircleReuleaux, Contained)
{
    Circle inner = Circle(Point(6.4,3.7), 1.0);
    Point verts[3] = { Point(6.4,5.4), Point(8.0,2.3) , Point(4.5,2.5) };
    ReuleauxTriangle outer = ReuleauxTriangle(verts);
    ASSERT_TRUE(inner.ContainedBy(outer));
}

TEST(CircleReuleaux, Outside)
{
    Circle inner = Circle(Point(15.0,15.0), 1.0);
    Point verts[3] = { Point(6.4,5.4), Point(8.0,2.3) , Point(4.5,2.5) };
    ReuleauxTriangle outer = ReuleauxTriangle(verts);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(CircleReuleaux, Surrounds)
{
    Circle inner = Circle(Point(6.4,3.7), 4.0);
    Point verts[3] = { Point(6.4,5.4), Point(8.0,2.3) , Point(4.5,2.5) };
    ReuleauxTriangle outer = ReuleauxTriangle(verts);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(CircleReuleaux, Intersects)
{
    Circle inner = Circle(Point(6.4,3.7), 1.5);
    Point verts[3] = { Point(6.4,5.4), Point(8.0,2.3) , Point(4.5,2.5) };
    ReuleauxTriangle outer = ReuleauxTriangle(verts);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(CircleReuleaux, TouchesInside)
{
    Circle inner = Circle(Point(6.5,3.5), 1.3);
    Point verts[3] = { Point(6.4,5.4), Point(8.0,2.3) , Point(4.5,2.5) };
    ReuleauxTriangle outer = ReuleauxTriangle(verts);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(CircleReuleaux, TouchesOutside)
{
    Circle inner = Circle(Point(8.9,4.6), 1.3);
    Point verts[3] = { Point(6.4,5.4), Point(8.0,2.3) , Point(4.5,2.5) };
    ReuleauxTriangle outer = ReuleauxTriangle(verts);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(CircleReuleaux, Coincident)
{
    Circle inner = Circle(Point(6.3,3.4), 1.5);
    Point verts[3] = { Point(6.4,5.4), Point(8.0,2.3) , Point(4.5,2.5) };
    ReuleauxTriangle outer = ReuleauxTriangle(verts);
    ASSERT_FALSE(inner.ContainedBy(outer));
}
/* 
   You'll need to extend this by adding additional tests for:
    1. Inner and Outer intersect (not contained)
    2. Inner is entirely outside Outer (not contained)
    3. Inner surrounds Outer (not contained)
    3. Inner coincident with Outer (not contained)
    4. Inner perimeter touches Outer perimeter, Inner is inside Outer (not contained)
    5. Inner perimeter touches Outer perimeter, Inner is outside Outer (not contained)

    Note that 4. and 5. should be taken care of by 1. but you need the tests to make sure
*/
