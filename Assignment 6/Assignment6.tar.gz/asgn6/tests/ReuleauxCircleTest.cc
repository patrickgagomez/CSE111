#include "Circle.h"
#include "Geom.h"
#include "Reuleaux.h"
#include <gtest/gtest.h>

TEST(ReuleauxCircle, Contained)
{
    Circle outer = Circle(Point(0.0,0.0), 5.0);
    Point verts[3] = { Point(0.0, 1.7), Point(-1.0, 0.0) , Point(1.0, 0.0) };
    ReuleauxTriangle inner = ReuleauxTriangle(verts);
    ASSERT_TRUE(inner.ContainedBy(outer));
}

TEST(ReuleauxCircle, Outside)
{
    Circle outer = Circle(Point(0.0,0.0), 5.0);
    Point verts[3] = { Point(10.0, 2.0), Point(12.0, -1.0) , Point(8.0, -1.0) };
    ReuleauxTriangle inner = ReuleauxTriangle(verts);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxCircle, Surrounds)
{
    Circle outer = Circle(Point(0.0,0.6), 0.5);
    Point verts[3] = { Point(0.0, 1.7), Point(-1.0, 0.0) , Point(1.0, 0.0) };
    ReuleauxTriangle inner = ReuleauxTriangle(verts);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxCircle, Intersects)
{
    Circle outer = Circle(Point(3.7, -1.8), 5);
    Point verts[3] = { Point(0.0, 1.7), Point(-1.0, 0.0) , Point(1.0, 0.0) };
    ReuleauxTriangle inner = ReuleauxTriangle(verts);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxCircle, TouchesInside)
{
    Circle outer = Circle(Point(4,0.5), 5);
    Point verts[3] = { Point(0.0, 1.7), Point(-1.0, 0.0) , Point(1.0, 0.0) };
    ReuleauxTriangle inner = ReuleauxTriangle(verts);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxCircle, TouchesOutside)
{
    Circle outer = Circle(Point(6,0), 5);
    Point verts[3] = { Point(0.0, 1.7), Point(-1.0, 0.0) , Point(1.0, 0.0) };
    ReuleauxTriangle inner = ReuleauxTriangle(verts);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

TEST(ReuleauxCircle, Coincident)
{
    Circle outer = Circle(Point(0,0.6), 0.9);
    Point verts[3] = { Point(0.0, 1.7), Point(-1.0, 0.0) , Point(1.0, 0.0) };
    ReuleauxTriangle inner = ReuleauxTriangle(verts);
    ASSERT_FALSE(inner.ContainedBy(outer));
}

/* 
   You'll need to extend this by adding additional tests for:
    1. Inner and Outer intersect (not contained)
    2. Inner is entirely outside Outer (not contained)
    3. Inner surrounds Outer (not contained)
    3. Inner coincident with Outer (not contained)
    4. Inner perimeter touches Outer perimeter, Inner is inside Outer (not contained)
    5. Inner perimeter touches Outer perimeter, Inner is outside Outer (not contained)

    Note that 4. and 5. should be taken care of by 1. but you need the tests to make sure
*/
