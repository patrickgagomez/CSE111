#include "Circle.h"
#include "Geom.h"
#include "Reuleaux.h"
#include "Containable.h"
#include "Polygon.h"
#include "Point.h"

#include <vector>

Circle::Circle(const Point &center, double radius)
    : cent(center), rad(radius) 
{ }

Point Circle::Center(){
    return this->cent;
}

double Circle::Radius(){
    return this->rad;
}

bool Circle::pointInside(const Point &check){
    const double dist2Center = Geom::Seperation(check, this->Center());
    return dist2Center < (this->Radius());
}

bool Circle::ContainedBy(Circle &circle){
    return Geom::Seperation(Center(), circle.Center()) < (circle.Radius() - Radius());
}

//CITATION:
//https://stackoverflow.com/questions/25701346/how-to-check-if-a-circle-lies-inside-of-convex-polygon#:~:text=First%20way%3A,the%20circle%20encloses%20the%20polygon.
bool Circle::ContainedBy(Polygon &polygon){
    
    std::vector<Point> verts = polygon.getPolyPoints();
    int n = verts.size();
    int i = 0;
    do {
        if (Geom::CircleLineIntersect(verts[i], verts[(i + 1) % n], *this)){
            return false;
        }
        i = (i + 1) % n;
    } while (i != 0);

    if (!polygon.checkInside(verts, this->Center())){
        //return false;
    }
    return true;
}

bool Circle::ContainedBy(ReuleauxTriangle &rt){
    Point a = rt.getPoint(1);
    Point b = rt.getPoint(2);
    Point c = rt.getPoint(3);

    double rad = Geom::Seperation(a, b);

    Circle sideA = Circle(a, rad);
    Circle sideB = Circle(b, rad);
    Circle sideC = Circle(c, rad);

   if (this->ContainedBy(sideA)) {
        if (this->ContainedBy(sideB)) {
            if (this->ContainedBy(sideC)) {
                return true;
            }
        }
   }
   return false;
}

