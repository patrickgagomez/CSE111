#include "Geom.h"
#include "Containable.h"
#include "Point.h"
#include "Circle.h"
#include "Reuleaux.h"
#include "Polygon.h"

double Geom::Seperation(const Point &a, const Point &b){
    return sqrt(pow(a.x - b.x, 2) + pow (a.y - b.y, 2));
}

Point Geom::rtCenter(ReuleauxTriangle &rt){
    Point a = rt.getPoint(1);
    Point b = rt.getPoint(2);
    Point c = rt.getPoint(3);

    double xCenter = (a.x + b.x + c.x)/3;
    double yCenter = (a.y + b.y + c.y)/3;

    Point rtCent = Point(xCenter, yCenter);
    return rtCent;
}

//CITATION:
//https://www.geeksforgeeks.org/check-line-touches-intersects-circle/
//https://bobobobo.wordpress.com/2008/01/07/solving-linear-equations-ax-by-c-0/
bool Geom::CircleLineIntersect(const Point &a, const Point &b, Circle &circle){
    Point c = circle.Center();

    double aDoub = (a.y - b.y);
    double bDoub = (b.x - a.x);
    double cDoub = ((a.x * b.y)-(b.x * a.y));

    double dist = (  abs(aDoub * c.x + bDoub * c.y + cDoub) / sqrt ( (pow(aDoub, 2)) + (pow(bDoub, 2))));

    if (circle.Radius() == dist){
        //return true;
    } else if (circle.Radius() > dist){
        return true;
    }
    return false;
}