#include "Reuleaux.h"
#include "Circle.h"
#include "Polygon.h"
#include "Geom.h"
#include "Containable.h"
#include "Point.h"
#include <vector>

ReuleauxTriangle::ReuleauxTriangle(const Point vertices[3])
    : a(vertices[0]), b(vertices[1]), c(vertices[2])
{ }

bool ReuleauxTriangle::ContainedBy(Circle &circle){
    //get distances
    const double aDist = Geom::Seperation(this->a, circle.Center());
    const double bDist = Geom::Seperation(this->b, circle.Center());
    const double cDist = Geom::Seperation(this->c, circle.Center());

    //check if the points are contained within the circle

    //CHANGE THESE TO circle.pointInside()
    bool aCheck =  aDist < (circle.Radius());
    bool bCheck =  bDist < (circle.Radius());
    bool cCheck =  cDist < (circle.Radius());
    //setup for next check...
    bool edgeB = false;

    //by choosing the closest point to the center...
    double closest = std::min({aDist, bDist, cDist});
    const double rad = Geom::Seperation(this->a, this->b);

    //we can check if that point's circle is contained within the
    //circle given (instead of just the point)

    //we do this because the outer edge of the circle belonging to the 
    //point closest to the center is the edge of the RT that might pass
    //through the edge of the original circle.
    if (closest == aDist){
        Circle checkEdge = Circle(this->a, rad);
        if (checkEdge.ContainedBy(circle)){
           //edgeB = true; 
        }
    } else if (closest == bDist){
        Circle checkEdge = Circle(this->b, rad);
        if (checkEdge.ContainedBy(circle)){
           edgeB = true; 
        }
    } else if (closest == cDist){
        Circle checkEdge = Circle(this->c, rad);
        if (checkEdge.ContainedBy(circle)){
           //edgeB = true; 
        }
    }

    //if all points are contained + the outer edge is within the circle...
    //it IS contained!
    if (aCheck == true && bCheck == true && cCheck == true && edgeB == true){
        return true;
    }
    return false;
}

bool ReuleauxTriangle::ContainedBy(Polygon &polygon){
    //check that all the points are inside the poly
    Point A = this->getPoint(1);
    Point B = this->getPoint(2);
    Point C = this->getPoint(3);

    std::vector<Point> points = polygon.getPolyPoints();

    bool aCheck = polygon.checkInside(points, A);
    bool bCheck = polygon.checkInside(points, B);
    bool cCheck = polygon.checkInside(points, C);

    //check that:
    //for all circles: intersections happen 2 times or less
    //any more and its not contained
    const double radOuter = Geom::Seperation(A, B);
    Circle sideA = Circle(A, radOuter);
    Circle sideB = Circle(B, radOuter);
    Circle sideC = Circle(C, radOuter);

    int n = points.size();
    int i = 0;
    int countA = 0;
    int countB = 0;
    int countC = 0;

    do {
        if (Geom::CircleLineIntersect(points[i], points[(i + 1) % n], sideA)){
            countA++;
            //std::cout << "Circle A intersected with line (" << points[i].x << ", " << points[i].y << ") -> (" << points[(i + 1) % n].x << ", " << points[(i + 1) % n].y << std::endl << "Intersection Count A: " << countA << std::endl; 
        }
        if (Geom::CircleLineIntersect(points[i], points[(i + 1) % n], sideB)){
            countB++;
            //std::cout << "Circle B intersected with line (" << points[i].x << ", " << points[i].y << ") -> (" << points[(i + 1) % n].x << ", " << points[(i + 1) % n].y << std::endl << "Intersection Count B: " << countB << std::endl; 
        }
        if (Geom::CircleLineIntersect(points[i], points[(i + 1) % n], sideC)){
            countC++;
            //std::cout << "Circle C intersected with line (" << points[i].x << ", " << points[i].y << ") -> (" << points[(i + 1) % n].x << ", " << points[(i + 1) % n].y << std::endl << "Intersection Count C: " << countC << std::endl; 
        }
        i = (i + 1) % n;
        //std::cout << "\n";
    } while (i != 0);
    //countA--;
    //countB--;

    if (countA > 2 || countB > 2 || countC > 2 ||
        aCheck == false || bCheck == false || cCheck == false){
        return false;
    }
    return true;
}

bool ReuleauxTriangle::ContainedBy(ReuleauxTriangle &rt){
    Point testA = rt.getPoint(0);
    Point testB = rt.getPoint(5);
    if (testA.x == -999 && testB.x == -999){
        testA.x = 0;
        testB.x = 0;
    }
    
    Point center = Geom::rtCenter(rt);
    const double aDist = Geom::Seperation(this->a, center);
    const double bDist = Geom::Seperation(this->b, center);
    const double cDist = Geom::Seperation(this->c, center);

    bool edgeB = false;
    double closest = std::min({aDist, bDist, cDist});
    const double radOuter = Geom::Seperation(rt.getPoint(1), rt.getPoint(2));

    Circle sideA = Circle(rt.getPoint(1), radOuter);
    Circle sideB = Circle(rt.getPoint(2), radOuter);
    Circle sideC = Circle(rt.getPoint(3), radOuter);

    bool aChecka = sideA.pointInside(this->a);
    bool aCheckb = sideB.pointInside(this->a);
    bool aCheckc = sideC.pointInside(this->a);

    bool bChecka = sideA.pointInside(this->b);
    bool bCheckb = sideB.pointInside(this->b);
    bool bCheckc = sideC.pointInside(this->b);

    bool cChecka = sideA.pointInside(this->c);
    bool cCheckb = sideB.pointInside(this->c);
    bool cCheckc = sideC.pointInside(this->c);

    const double radInner = Geom::Seperation(this->a, this->b);

    if (closest == aDist){
        Circle checkEdge = Circle(this->a, radInner);
        if (checkEdge.ContainedBy(sideA) && checkEdge.ContainedBy(sideB) && checkEdge.ContainedBy(sideC)){
           edgeB = true; 
        }
    } else if (closest == bDist){
        Circle checkEdge = Circle(this->b, radInner);
        if (checkEdge.ContainedBy(sideA) && checkEdge.ContainedBy(sideB) && checkEdge.ContainedBy(sideC)){
           //edgeB = true; 
        }
    } else if (closest == cDist){
        Circle checkEdge = Circle(this->c, radInner);
        if (checkEdge.ContainedBy(sideA) && checkEdge.ContainedBy(sideB) && checkEdge.ContainedBy(sideC)){
           edgeB = true; 
        }
    }

    if (aChecka == true && aCheckb == true && aCheckc == true){
        if (bChecka == true && bCheckb == true && bCheckc == true){
            if (cChecka == true && cCheckb == true && cCheckc == true){
                if (edgeB == true){
                    return true;
                }
            }
        }
    }
    return false;

}

Point ReuleauxTriangle::getPoint(int which){
    Point dummy = Point(-999,-999);
    if (which <= 0 || which > 3){
        return dummy;
    }

    if (which == 1){
        return this->a;
    } else if (which == 2){
        return this->b;
    } else {
        return this->c;
    }
}
