#include "Reuleaux.h"
#include "Circle.h"
#include "Polygon.h"
#include "Geom.h"
#include "Containable.h"
#include "Point.h"
#include <vector>

Polygon::Polygon(std::vector<Point> vertices)
    : points(vertices)
{ }

bool Polygon::ContainedBy(Circle &circle){
    for (Point p : points){
        bool contain = circle.pointInside(p);
        if (contain == false){
            return false;
        }
    }
    return true;
}

bool Polygon::ContainedBy(Polygon &polygon){
    std::vector<Point> pApoints = this->getPolyPoints();
    std::vector<Point> pBpoints = polygon.getPolyPoints();
    for (Point p : pApoints){
        bool contain = checkInside(pBpoints, p);
        if (contain == false){
            return false;
        }
    }
    return true;
}

bool Polygon::ContainedBy(ReuleauxTriangle &rt){
    //create 3 circles for the rt
    const double radOuter = Geom::Seperation(rt.getPoint(1), rt.getPoint(2));
    Circle sideA = Circle(rt.getPoint(1), radOuter);
    Circle sideB = Circle(rt.getPoint(2), radOuter);
    Circle sideC = Circle(rt.getPoint(3), radOuter);
    //check that all points are within those 3 circles
    std::vector<Point> points = this->getPolyPoints();
    for (Point p : points){
        if (!sideA.pointInside(p) || !sideB.pointInside(p) || !sideC.pointInside(p)){
            return false;
        }
    }
    return true;
}

std::vector<Point> Polygon::getPolyPoints(){
    return this->points;
}

//CITATION:
//https://www.geeksforgeeks.org/how-to-check-if-a-given-point-lies-inside-a-polygon/bool Polygon::checkInside(std::vector<Point> verts, Point p){
bool Polygon::checkInside(std::vector<Point> verts, Point p){
    int n = verts.size();
    Point wayOff = Point( 9999,p.y );

    int count = 0;
    int i = 0;
    do {
        if (isIntersect( verts[i], verts[(i + 1) % n], p, wayOff )){
            if (direction(verts[i], p, verts[(i + 1) % n]) == 0){
                return onLine(verts[i], verts[(i + 1) % n], p);
            }
            count++;
        }
        i = (i + 1) % n;
    } while (i != 0);
    
    return count & 1;
}

bool Polygon::isIntersect(Point l1A, Point l1B, Point l2A, Point l2B){
    // Four direction for two lines and points of other line
    int dir1 = direction(l1A, l1B, l2A);
    int dir2 = direction(l1A, l1B, l2B);
    int dir3 = direction(l2A, l2B, l1A);
    int dir4 = direction(l2A, l2B, l1B);
 
    // When intersecting
    if (dir1 != dir2 && dir3 != dir4)
        return true;
 
    // When p2 of line2 are on the line1
    if (dir1 == 0 && onLine(l1A, l1B, l2A))
        return true;
 
    // When p1 of line2 are on the line1
    /*
    if (dir2 == 0 && onLine(l1A, l1B, l2B))
        return true;
    */
    // When p2 of line1 are on the line2
    if (dir3 == 0 && onLine(l2A, l2B, l1A))
        return true;
 
    /*
    // When p1 of line1 are on the line2
    if (dir4 == 0 && onLine(l2A, l2B, l1B))
        return true;
    */
    return false;
}

int Polygon::direction(Point a, Point b, Point c){
    int val = (b.y - a.y) * (c.x - b.x)
              - (b.x - a.x) * (c.y - b.y);
 
    if (val == 0)
        // Colinear
        return 0;
 
    else if (val < 0)
        // Anti-clockwise direction
        return 2;
 
    // Clockwise direction
    return 1;
}

bool Polygon::onLine(Point l1A, Point l1B, Point p){
    if (p.x <= std::max(l1A.x, l1B.x)
        && p.x <= std::min(l1A.x, l1B.x)
        && (p.y <= std::max(l1A.y, l1B.y)
        && p.y <= std::min(l1A.y, l1B.y)))
        return true;
 
    return false;
}