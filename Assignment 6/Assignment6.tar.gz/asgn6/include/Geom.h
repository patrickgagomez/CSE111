#ifndef _GEOM_H_
#define _GEOM_H_

#include <math.h>
#include "Containable.h"
#include "Point.h"

class Geom {
    public:
        static double Seperation(const Point &a, const Point &b);
        static Point rtCenter(ReuleauxTriangle &rt);
        static bool CircleLineIntersect(const Point &a, const Point &b, Circle &circle);
};


#endif