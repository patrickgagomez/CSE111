/*
 * Copyright (C) 2018 David C. Harrison. All right reserved.
 *
 * You may not use, distribute, publish, or modify this code without 
 * the express written permission of the copyright holder.
 */

#ifndef _POLYGON_H_
#define _POLYGON_H_

#include <vector>

#include "Containable.h"
#include "Point.h"

class Polygon : public Containable {
  private:
    std::vector<Point> points;
  public:
    // do not modify or remove this constructor
    Polygon(std::vector<Point> vertices /* clockwise */);

    // do not modify or remove these functions
    bool ContainedBy(Circle &circle);
    bool ContainedBy(Polygon &polygon);
    bool ContainedBy(ReuleauxTriangle &rt);

    std::vector<Point> getPolyPoints();
    bool checkInside(std::vector<Point> verts, Point p);
    bool isIntersect(Point l1A, Point l1B, Point l2A, Point l2B);
    int direction(Point a, Point b, Point c);
    bool onLine(Point l1A, Point l1B, Point p);

};

#endif
